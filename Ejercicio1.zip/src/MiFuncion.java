public class MiFuncion {
    /// función con tres parámetros que será llamada en la clase principal (Main)
    public static int suma (int a, int b, int c){
        int suma = a + b + c ;
        return suma;
    }


}
